package fr.uge.poo.ducks;

public interface DuckFactory {
    Duck withName(String name);
}

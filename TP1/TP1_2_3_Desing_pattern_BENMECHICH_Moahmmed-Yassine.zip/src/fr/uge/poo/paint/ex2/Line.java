package fr.uge.poo.paint.ex2;

public record Line(int x0, int y0, int x1, int y1){}

import fr.uge.poo.uberclient.question1.UberClient;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
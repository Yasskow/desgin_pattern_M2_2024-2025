package fr.uge.poo.uberclient.question1;

import java.util.List;

@FunctionalInterface
public interface UberClientFormatter {
    String format(UberClient.UberClientInfo uberClientInfo);

}

